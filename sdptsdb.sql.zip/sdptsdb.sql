-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Φιλοξενητής: 127.0.0.1
-- Χρόνος δημιουργίας: 15 Ιαν 2018 στις 20:21:51
-- Έκδοση διακομιστή: 10.1.28-MariaDB
-- Έκδοση PHP: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `sdptsdb`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `tasks`
--

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `title` varchar(45) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `state` varchar(45) NOT NULL,
  `assignee` varchar(45) NOT NULL,
  `date_created` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `tasks`
--

INSERT INTO `tasks` (`id`, `title`, `description`, `state`, `assignee`, `date_created`) VALUES
(1, 'Dump title 1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porttitor leo non sapien porttitor porta. Suspendisse ac interdum ipsum. Nam est felis, luctus id convallis ut, auctor eget dui. Curabitur sollicitudin luctus luctus.', 'New', 'giannis', '14-01-2018'),
(2, 'Dump title 2', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porttitor leo non sapien porttitor porta. Suspendisse ac interdum ipsum. Nam est felis, luctus id convallis ut, auctor eget dui. Curabitur sollicitudin luctus luctus.', 'Completed', 'kostas', '14-01-2018'),
(3, 'Dump title 3', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porttitor leo non sapien porttitor porta. Suspendisse ac interdum ipsum. Nam est felis, luctus id convallis ut, auctor eget dui. Curabitur sollicitudin luctus luctus.', 'Under Dev', 'Unassigned', '14-01-2018'),
(4, 'Dump title 4', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porttitor leo non sapien porttitor porta. Suspendisse ac interdum ipsum. Nam est felis, luctus id convallis ut, auctor eget dui. Curabitur sollicitudin luctus luctus.', 'Under Dev', 'mixalis', '14-01-2018'),
(5, 'Dump title 5', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porttitor leo non sapien porttitor porta. Suspendisse ac interdum ipsum. Nam est felis, luctus id convallis ut, auctor eget dui. Curabitur sollicitudin luctus luctus.', 'New', 'thodoris', '14-01-2018'),
(6, 'Dump title 6', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porttitor leo non sapien porttitor porta. Suspendisse ac interdum ipsum. Nam est felis, luctus id convallis ut, auctor eget dui. Curabitur sollicitudin luctus luctus.', 'Closed', 'nikos', '14-01-2018'),
(7, 'Dump title 7', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porttitor leo non sapien porttitor porta. Suspendisse ac interdum ipsum. Nam est felis, luctus id convallis ut, auctor eget dui. Curabitur sollicitudin luctus luctus.', 'New', 'nikolaos', '14-01-2018'),
(8, 'Dump title 8', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porttitor leo non sapien porttitor porta. Suspendisse ac interdum ipsum. Nam est felis, luctus id convallis ut, auctor eget dui. Curabitur sollicitudin luctus luctus.', 'Under Dev', 'kostas', '14-01-2018'),
(9, 'Dump title 9', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porttitor leo non sapien porttitor porta. Suspendisse ac interdum ipsum. Nam est felis, luctus id convallis ut, auctor eget dui. Curabitur sollicitudin luctus luctus.', 'Under Dev', 'giannis', '14-01-2018'),
(10, 'Dump title 10', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porttitor leo non sapien porttitor porta. Suspendisse ac interdum ipsum. Nam est felis, luctus id convallis ut, auctor eget dui. Curabitur sollicitudin luctus luctus.', 'New', 'giannis', '14-01-2018'),
(11, 'Dump title 11', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porttitor leo non sapien porttitor porta. Suspendisse ac interdum ipsum. Nam est felis, luctus id convallis ut, auctor eget dui. Curabitur sollicitudin luctus luctus.', 'New', 'giorgos', '14-01-2018'),
(12, 'Dump title 12', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porttitor leo non sapien porttitor porta. Suspendisse ac interdum ipsum. Nam est felis, luctus id convallis ut, auctor eget dui. Curabitur sollicitudin luctus luctus.', 'Under Dev', 'thodoris', '14-01-2018'),
(13, 'Dump title 13', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porttitor leo non sapien porttitor porta. Suspendisse ac interdum ipsum. Nam est felis, luctus id convallis ut, auctor eget dui. Curabitur sollicitudin luctus luctus.', 'Closed', 'nikolaos', '14-01-2018'),
(14, 'Dump title 14', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porttitor leo non sapien porttitor porta. Suspendisse ac interdum ipsum. Nam est felis, luctus id convallis ut, auctor eget dui. Curabitur sollicitudin luctus luctus.', 'Completed', 'mixalis', '14-01-2018'),
(15, 'Dump title 15', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porttitor leo non sapien porttitor porta. Suspendisse ac interdum ipsum. Nam est felis, luctus id convallis ut, auctor eget dui. Curabitur sollicitudin luctus luctus.', 'Closed', 'giorgos', '14-01-2018');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'giorgos', 'giorgos123'),
(2, 'thodoris', 'thodoris123'),
(3, 'giannis', 'giannis123'),
(4, 'kostas', 'kostas123'),
(5, 'nikolaos', 'nikolaos123'),
(6, 'mixalis', 'mixalis123');

--
-- Ευρετήρια για άχρηστους πίνακες
--

--
-- Ευρετήρια για πίνακα `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Ευρετήρια για πίνακα `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username_UNIQUE` (`username`);

--
-- AUTO_INCREMENT για άχρηστους πίνακες
--

--
-- AUTO_INCREMENT για πίνακα `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT για πίνακα `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
